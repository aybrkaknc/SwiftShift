(function(){const M={processText(e){if(!e)return null;const n=e.trim();return n.length===0?null:n},getSelection(){const e=window.getSelection();return e?this.processText(e.toString()):null}},b={processVideoUrl(e,n){try{const s=new URL(e);if((s.hostname.includes("youtube.com")||s.hostname.includes("youtu.be"))&&n&&n>0){const o=Math.floor(n);s.searchParams.set("t",o.toString()+"s")}return s.toString()}catch{return e}},isImageUrl(e){return/\.(jpg|jpeg|png|gif|webp|bmp|svg)$/i.test(e)}};chrome.runtime.onMessage.addListener((e,n,s)=>{if(e.type==="CAPTURE_CONTENT")return C().then(o=>s(o)),!0;if(e.type==="START_REGION_CAPTURE")return T(e.targetId,e.threadId,e.targetName),s({success:!0}),!0});async function C(){const e=M.getSelection();if(e)return{text:e};let n=window.location.href;const s=document.title,o=document.querySelector("video");return o&&(n=b.processVideoUrl(n,o.currentTime)),{text:`${s}
${n}`,isPage:!0}}function T(e,n,s){const o=document.getElementById("swiftshift-region-overlay");o&&o.remove();const t=document.createElement("div");t.id="swiftshift-region-overlay",t.style.cssText=`
        position: fixed;
        top: 0;
        left: 0;
        width: 100vw;
        height: 100vh;
        background: rgba(0, 0, 0, 0.3);
        cursor: crosshair;
        z-index: 2147483647;
    `;const i=document.createElement("div");i.style.cssText=`
        position: fixed;
        border: 2px dashed #F4AB25;
        background: rgba(244, 171, 37, 0.1);
        pointer-events: none;
        display: none;
    `,t.appendChild(i);const d=document.createElement("div");d.style.cssText=`
        position: fixed;
        top: 20px;
        left: 50%;
        transform: translateX(-50%);
        background: #1a1a1a;
        color: white;
        padding: 12px 24px;
        border-radius: 8px;
        font-family: system-ui, sans-serif;
        font-size: 14px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.3);
        border: 1px solid rgba(255,255,255,0.1);
    `,d.textContent="✂️ Yakalamak istediğiniz alanı seçin (ESC ile iptal)",t.appendChild(d);let r=0,c=0,l=!1;const w=a=>{l=!0,r=a.clientX,c=a.clientY,i.style.display="block",i.style.left=`${r}px`,i.style.top=`${c}px`,i.style.width="0",i.style.height="0"},v=a=>{if(!l)return;const u=a.clientX,h=a.clientY,f=Math.min(r,u),g=Math.min(c,h),p=Math.abs(u-r),m=Math.abs(h-c);i.style.left=`${f}px`,i.style.top=`${g}px`,i.style.width=`${p}px`,i.style.height=`${m}px`},E=async a=>{if(!l)return;l=!1;const u=a.clientX,h=a.clientY,f=Math.min(r,u),g=Math.min(c,h),p=Math.abs(u-r),m=Math.abs(h-c);t.remove(),!(p<10||m<10)&&chrome.runtime.sendMessage({type:"REGION_CAPTURE_SELECTED",targetId:e,threadId:n,targetName:s,region:{left:f,top:g,width:p,height:m},devicePixelRatio:window.devicePixelRatio||1,pageTitle:document.title,pageUrl:window.location.href})},x=a=>{a.key==="Escape"&&(t.remove(),document.removeEventListener("keydown",x))};t.addEventListener("mousedown",w),t.addEventListener("mousemove",v),t.addEventListener("mouseup",E),document.addEventListener("keydown",x),document.body.appendChild(t)}let y={x:0,y:0};document.addEventListener("contextmenu",e=>{y={x:e.clientX,y:e.clientY}},!0);chrome.runtime.onMessage.addListener((e,n,s)=>{if(e.type==="GET_CLICKED_MEDIA"){const o=S(y.x,y.y);return s(o||null),!0}return!1});function S(e,n){const s=document.elementsFromPoint(e,n),o=[];for(const t of s){const i=t.getBoundingClientRect(),d=i.width*i.height;if(!(i.width<10||i.height<10)){if(t instanceof HTMLImageElement&&t.src&&o.push({type:"image",src:t.currentSrc||t.src,score:10+d/1e4}),t instanceof HTMLVideoElement)try{const r=L(t);r?o.push({type:"image",src:r,score:20}):t.poster&&o.push({type:"image",src:t.poster,score:15})}catch{t.poster&&o.push({type:"image",src:t.poster,score:5})}if(t instanceof HTMLCanvasElement)try{const r=t.toDataURL("image/png");o.push({type:"image",src:r,score:12+d/1e4})}catch{}if(t instanceof SVGElement)try{new XMLSerializer().serializeToString(t)}catch{}try{const c=window.getComputedStyle(t).backgroundImage;if(c&&c!=="none"&&c.startsWith("url(")){const l=c.match(/url\(['"]?(.*?)['"]?\)/);l&&l[1]&&o.push({type:"image",src:l[1],score:5+d/2e4})}}catch{}}}return o.length>0?(o.sort((t,i)=>i.score-t.score),console.log("Media Candidates:",o),o[0]):null}function L(e){try{const n=document.createElement("canvas");n.width=e.videoWidth,n.height=e.videoHeight;const s=n.getContext("2d");if(s)return s.drawImage(e,0,0,n.width,n.height),n.toDataURL("image/jpeg",.85)}catch(n){console.warn("Cannot capture video frame (CORS likely):",n)}return null}
})()
