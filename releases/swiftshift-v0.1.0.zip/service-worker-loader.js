import './assets/index.ts-3bc35b58.js';
