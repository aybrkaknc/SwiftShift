import b from"./html2canvas.esm-e0a7d97b.js";const M={processText(e){if(!e)return null;const o=e.trim();return o.length===0?null:o},getSelection(){const e=window.getSelection();return e?this.processText(e.toString()):null}},C={processVideoUrl(e,o){try{const n=new URL(e);if((n.hostname.includes("youtube.com")||n.hostname.includes("youtu.be"))&&o&&o>0){const t=Math.floor(o);n.searchParams.set("t",t.toString()+"s")}return n.toString()}catch{return e}},isImageUrl(e){return/\.(jpg|jpeg|png|gif|webp|bmp|svg)$/i.test(e)}};chrome.runtime.onMessage.addListener((e,o,n)=>{if(e.type==="CAPTURE_CONTENT")return L().then(t=>n(t)),!0;if(e.type==="START_REGION_CAPTURE")return S(e.targetId,e.threadId,e.targetName),n({success:!0}),!0;if(e.type==="CAPTURE_FULL_PAGE_FOR_PDF")return T().then(t=>n(t)),!0});async function T(){try{const e=await b(document.body,{useCORS:!0,logging:!1,allowTaint:!0,scrollY:-window.scrollY});return{success:!0,dataUrl:e.toDataURL("image/png"),width:e.width,height:e.height,title:document.title,url:window.location.href}}catch(e){return console.error("PDF Capture Failed:",e),{success:!1,error:String(e)}}}async function L(){const e=M.getSelection();if(e)return{text:e};let o=window.location.href;const n=document.title,t=document.querySelector("video");return t&&(o=C.processVideoUrl(o,t.currentTime)),{text:`${n}
${o}`,isPage:!0}}function S(e,o,n){const t=document.getElementById("swiftshift-region-overlay");t&&t.remove();const i=document.createElement("div");i.id="swiftshift-region-overlay",i.style.cssText=`
        position: fixed;
        top: 0;
        left: 0;
        width: 100vw;
        height: 100vh;
        background: rgba(0, 0, 0, 0.3);
        cursor: crosshair;
        z-index: 2147483647;
    `;const r=document.createElement("div");r.style.cssText=`
        position: fixed;
        border: 2px dashed #F4AB25;
        background: rgba(244, 171, 37, 0.1);
        pointer-events: none;
        display: none;
    `,i.appendChild(r);const c=document.createElement("div");c.style.cssText=`
        position: fixed;
        top: 20px;
        left: 50%;
        transform: translateX(-50%);
        background: #1a1a1a;
        color: white;
        padding: 12px 24px;
        border-radius: 8px;
        font-family: system-ui, sans-serif;
        font-size: 14px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.3);
        border: 1px solid rgba(255,255,255,0.1);
    `,c.textContent="✂️ Yakalamak istediğiniz alanı seçin (ESC ile iptal)",i.appendChild(c);let a=0,l=0,p=!1;const w=s=>{p=!0,a=s.clientX,l=s.clientY,r.style.display="block",r.style.left=`${a}px`,r.style.top=`${l}px`,r.style.width="0",r.style.height="0"},v=s=>{if(!p)return;const d=s.clientX,u=s.clientY,f=Math.min(a,d),g=Math.min(l,u),h=Math.abs(d-a),m=Math.abs(u-l);r.style.left=`${f}px`,r.style.top=`${g}px`,r.style.width=`${h}px`,r.style.height=`${m}px`},E=async s=>{if(!p)return;p=!1;const d=s.clientX,u=s.clientY,f=Math.min(a,d),g=Math.min(l,u),h=Math.abs(d-a),m=Math.abs(u-l);i.remove(),!(h<10||m<10)&&chrome.runtime.sendMessage({type:"REGION_CAPTURE_SELECTED",targetId:e,threadId:o,targetName:n,region:{left:f,top:g,width:h,height:m},devicePixelRatio:window.devicePixelRatio||1,pageTitle:document.title,pageUrl:window.location.href})},x=s=>{s.key==="Escape"&&(i.remove(),document.removeEventListener("keydown",x))};i.addEventListener("mousedown",w),i.addEventListener("mousemove",v),i.addEventListener("mouseup",E),document.addEventListener("keydown",x),document.body.appendChild(i)}let y={x:0,y:0};document.addEventListener("contextmenu",e=>{y={x:e.clientX,y:e.clientY}},!0);chrome.runtime.onMessage.addListener((e,o,n)=>{if(e.type==="GET_CLICKED_MEDIA"){const t=P(y.x,y.y);return n(t||null),!0}return!1});function P(e,o){const n=document.elementsFromPoint(e,o);for(const t of n){if(t instanceof HTMLImageElement&&t.src)return{src:t.src,type:"image"};if(t instanceof HTMLVideoElement){const i=t.currentSrc||t.src||t.poster;if(i)return{src:i,type:"video"}}try{const r=window.getComputedStyle(t).backgroundImage;if(r&&r!=="none"&&r.startsWith("url(")){const c=r.match(/url\(['"]?(.*?)['"]?\)/);if(c&&c[1])return{src:c[1],type:"image"}}}catch{}}return null}
